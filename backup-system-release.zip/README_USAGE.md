# 数据备份系统 — 使用说明

## 快速开始

### 1. 安装依赖（离线，仅首次）
```
install.bat
```

### 2. 配置
复制 `config.example.json` 为 `config.json`，按实际环境填写：
- `databases` — 数据库连接信息
- `disks.min_free_gb` — 磁盘切换阈值（默认 100 GB）
- `email` — SMTP 告警邮件配置（可设 `enabled: false` 关闭）

### 3. 启动备份（手动单次）
```
start.bat --once
```

### 4. 启动持续调度（每天凌晨自动执行）
```
start.bat
```

### 5. 查看备份状态 Dashboard
```
start_dashboard.bat
```
打开浏览器访问 http://127.0.0.1:8080

---

## 常用命令

| 命令 | 说明 |
|------|------|
| `start.bat --dry-run` | 查看今日调度计划，不执行 |
| `start.bat --once` | 执行一次全部备份任务后退出 |
| `start.bat --once --job mysql_app` | 只执行指定任务 |
| `start_dashboard.bat` | 启动 Dashboard |

---

## 目录结构

```
backup-system-release/
├── src/          # Python 源码
├── dashboard/    # 前端可视化
├── vendor/       # 离线依赖
├── config.json   # 配置文件（自行创建）
├── install.bat   # 首次安装
├── start.bat     # 启动备份
└── start_dashboard.bat  # 启动 Dashboard
```
