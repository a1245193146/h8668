"""run_server.py — Serve the backup dashboard on localhost:8080.

Usage:
  python src/run_server.py                      # serve only (dashboard-only mode)
  python src/run_server.py --dashboard-only     # same
  python src/run_server.py --port 9090          # custom port
"""
from __future__ import annotations

import argparse
import http.server
import os
import sys
from pathlib import Path


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="run_server",
                                description="Serve the backup dashboard")
    p.add_argument("--dashboard-only", action="store_true",
                   help="Only start the HTTP server (default behaviour)")
    p.add_argument("--port", type=int, default=8080, help="HTTP port (default: 8080)")
    p.add_argument("--host", default="127.0.0.1", help="Bind address (default: 127.0.0.1)")
    return p


def serve(host: str = "127.0.0.1", port: int = 8080, dashboard_dir: str | None = None) -> None:
    """Start a simple HTTP server serving the dashboard directory."""
    if dashboard_dir is None:
        # Locate dashboard/ relative to project root (one level above src/)
        src_dir = Path(__file__).parent
        project_root = src_dir.parent
        dashboard_dir = str(project_root / "dashboard")

    if not Path(dashboard_dir).is_dir():
        print(f"[ERROR] Dashboard directory not found: {dashboard_dir}", file=sys.stderr)
        sys.exit(1)

    os.chdir(dashboard_dir)
    handler = http.server.SimpleHTTPRequestHandler
    handler.log_message = lambda self, fmt, *args: None  # suppress per-request logs

    with http.server.HTTPServer((host, port), handler) as httpd:
        print(f"[run_server] Dashboard → http://{host}:{port}/")
        print(f"[run_server] Serving from: {dashboard_dir}")
        print("[run_server] Press Ctrl+C to stop.")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n[run_server] Stopped.")


def main() -> int:
    args = _build_parser().parse_args()
    serve(host=args.host, port=args.port)
    return 0


if __name__ == "__main__":
    sys.exit(main())
